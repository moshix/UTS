main(argc,argv)
int argc;
char **argv;
{
	int i;
	char buf[512];
	char *cp1,*cp2;
	cp2 = buf;
	for(i=1;i<argc;i++){
		cp1 = argv[i];
		while(*cp1) *cp2++ = *cp1++;
		*cp2++ = ' ';
	}
	*cp2 = 0;
	cpcmd(buf);
}
