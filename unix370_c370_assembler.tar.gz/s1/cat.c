char buf[512];

main(argc,argv)
int argc;
char **argv;
{
	int i,fd;
	if(argc <= 1) {
		docat(0);
		exit();
	}
	for(i=1;i<argc;i++) {
		if(argv[i][0] == '-' && argv[i][1] == '\0') docat(0);
		else {
			if((fd = open(argv[i],0)) >= 0) {
				docat(fd);
				close(fd);
			}
		}
	}
}

docat(fd)
int fd;
{
	int n;
	while((n = read(fd, buf, 512)) > 0)
		write(1, buf, n);
}
