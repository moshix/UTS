#define NTRMS 4

char tty[] "/dev/ttyx";
main()
{
	int pids[NTRMS];
	int i,j;
	for(i=0;i<NTRMS;i++) pids[i] = start(i);
	for(;;) {
		j = wait(&i);
		for(i=0;i<NTRMS;i++) if(j == pids[i]) pids[i] = start(i);
	}
}

start(line)
{
	int p;
	if((p = fork()) == 0) {
		tty[8] = '0' + line;
		open(tty, 2);
		dup(0);
		dup(0);
		execl("/bin/sh","-",0);
		write(open("/dev/cons",1),"No Shell\n",9);
		exit();
	}
	return(p);
}
