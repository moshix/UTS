#
/*
	size -- determine object size

*/

#define MAGIC1  #47f00020
#define MAGIC2	#47f00024
#define HDRLEN	32

main(argc, argv)
char **argv;
{
	int buf[HDRLEN/4], f, ac, sum;

	ac = argc;
	if (ac==1) {
		*argv = "a.out";
		ac++;
		--argv;
	}
	while(--ac) {
		++argv;
		if((f=open(*argv, 0))<0) {
			printf("%s not found\n", *argv);
			continue;
		}
		read(f, buf, HDRLEN);
		if(buf[0]!=MAGIC1 && buf[0]!=MAGIC2) {
			printf("Bad format: %s\n", *argv);
			close(f);
			continue;
		}
		if (argc>2)
			printf("%s: ", *argv);
		printf("%d+%d+%d=", buf[1],buf[2],buf[3]);
		sum = buf[1]+buf[2]+buf[3];
		printf("%d (%o)\n", sum, sum);
		close(f);
	}
}
