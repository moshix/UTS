main()
{

	sync();
}
