struct fb {
	int	size;
	char	*next;
};

int	_freech[] {
	0,
	-1,
};
int	slop	4;

calloc(nitems, itemsize)
{
	int size, asize, *v;
 /*
	struct fb *np, *cp;
  */ char *np, *cp;

	if ((size = nitems*itemsize) == 0)
		return(0);
	size =+ 7;
	size =& ~03;
	for (;;) {
		for (cp=_freech; (np= cp->next) != -1; cp=np) {
			if (np->size>=size) {
				if (size+slop >= np->size) {
					cp->next = np->next;
					return(&np->next);
				}
				cp = cp->next = np+size;
				cp->size = np->size - size;
				cp->next = np->next;
				np->size = size;
				return(&np->next);
			}
		}
		asize = size<1020? 1024: size+4;
		cp = getmain(asize, asize<<2);
		if (cp->next <= 0)
			return(-1);
		v = cp->next;
		v[0] = cp->size-4;
		v[1] = cp->next+4;
		cfree(v+1);
	}
}
