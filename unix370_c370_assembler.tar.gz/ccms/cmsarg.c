/* Convert CMS argument list into C equivalent */

# define MAXNARG 64

char _args_[400];
char *_argv_[MAXNARG];
_gtargs()
{
	int i,*intparm,argc;
	char *parmlist,*argv,*lastarg;

	/* find register 1 which was copied to register 3 */
	parmlist = genreg(3,0);
	/* Zero high order byte */
	i = parmlist << 8;
	parmlist = i >> 8;
	argc = 0;
	argv = _args_;
	lastarg = argv;
	for(;;)
	{
		intparm = parmlist;
		/* Cms arg list is terminated by hex FFFFFFFFFFFFFFFF,
		   or two words of -1 */
		if(*intparm == -1) return(argc);
		i=0;
		while(*parmlist != ' ' && i < 8)
		{
			*argv++ = *parmlist++;
			i++;
		}
		*argv++ = '\0';
		parmlist =+ 8-i; /* Bump pointer to next doubleword */
		_argv_[argc++] = lastarg;
		lastarg = argv;
	}
}
