int kludge 0; 	/* This is so a switch table won't be the
		   first thing in the data csect, to get
		   around a bug in the switch code.
		 */

scanf (p1, p2, p3, p4, z0,z1,z2,z3,z4,z5,z6,z7,z8,z9)
	int p1, p2, p3, p4;
{
/* first arg can be a control string, a file id, or -1 */
	int ptrs[10], nptrs, j, ip, flp, k;
	extern int cin;
extern (*_Igetc)(), (*_Iungc)(), cgetc(), ungetc(), _Igstr(), _Iungs();
extern char *_Iinpt;
ip = 0;
if (p1 == -1)
  {k = 1; _Iinpt = p2;}
else if (p1 >= 0 && p1 < 10)
  k = 0;
else
  k = -1;
if (k <= 0)
  {_Igetc = cgetc; _Iungc = ungetc;}
else
  {_Igetc = _Igstr; _Iungc = _Iungs;}
nptrs = nargs(14) -2 - k;
for (j= 0; j < nptrs; j++)
	ptrs[ip++] = (&p3)[j+k];
return (_Iscan ((k==0 ?  p1 : cin), (&p2)[k], ptrs));
}

_Iscan (fileid, format, listp)
	char *format;
	int *listp;
{
	char ch, _Inxch();
	int nmatch;
	extern int _Isfil;
	_Isfil = fileid;
nmatch = 0;
while (1) switch (ch= *format++)
	{
	case '\0': return (nmatch);
	case '%': switch (_Isfrm(&format, *listp++))
			{
			case 0: listp--; break;
			case -1: return (nmatch > 0 ? nmatch : -1);
			default: nmatch++;
			}
	case ' ':
	case '\n':
	case '\t': break;
	default: if (ch != _Inxch())
			return(nmatch);
	}
}

int _Isfil 0;

_Ichar (cptr)
	char *cptr;
{
	char ch, _Inxch();

if ((ch = _Inxch()) < 0)
	return (-1);
if (cptr == 0)
	return (0);
*cptr = ch;
return (1);
}

/*%%%%%
_Iflot (fptr, length)
	float *fptr;
	int length;
{
	char temp[75];
	int _Inodg();
	float x;
	double atof();

if (_Isstr(temp, length, _Inodg) < 0)
	return (-1);
x = atof(temp);
if (fptr == 0)
	return (0);
*fptr = x;
return (1);
}

%%%%%*/
_Inodg (ch)
char ch;
{
if (_Idigt(ch)) return (0);
switch (ch)
	{
	case 'E':
	case 'e':
	case '.': case '+': case '-':
		return (0);
	}
return (1);
}

_Isfrm (spec, pointer)
	char **spec;
	int pointer;
{
	int length, lflag, _Iestr(), _Ispnd();
	char ch;
length = lflag = 0;
while (1) switch (ch = *((*spec)++))
	{
	case '*': pointer=0; break;
	case '0': case '1': case '2': case '3': case '4':
	case '5': case '6': case '7': case '8': case '9':
		length = length*10 + ch - '0' ;
		lflag++;
		break;
	case 'o': case 'O': /* octal */
		return(_Iint(pointer, lflag ? length : 100, 8));
	case 'x': case 'X': /* hex */
		return(_Iint(pointer, lflag ? length : 100, 16));
	case 'd': case 'D': /* decimal */
		return (_Iint(pointer, lflag ? length : 100, 10));
	case 'c': case 'C': /* character */
		return (_Ichar(pointer));
	case 's': case 'S': /* string */
		return (_Isstr(pointer, lflag ? length : 100, _Iestr));
	case 'f': case 'F':
	case 'e': case 'E': /* float */
 /*%%%%
		return (_Iflot(pointer, lflag ? length : 100)); 
 */  ermsg("SCAN: no floating point\n",0); /*%%%%*/
	case 'l': case 'L': /* double (long */
 /*%%%%% ermsg("SCAN: no floating point\n",0);
		return (_Ilong (pointer, lflag ? length : 100));
 %%%%*/
	case '[': /* special strings */
		_Imtab(spec);
		return (_Isstr (pointer, lflag ? length : 100, _Ispnd));
	case '%':
		if (_Inxch() != '%')
			return (-1);
		return(0);
	case '\0':
		_Ierr("scanf: bad format termination\n");
	default: _Ierr ("scanf: format character %c", ch);
	}
}
_Iint (iptr, length, numbase)
	int *iptr, length;
{
	int n, minus, numdig;
	extern int _Isfil, (*_Iungc)(), (*_Igetc)();
	int c, dval;

n = minus = numdig = 0;
switch ((c=_Inxch()))
	{
	case '-': minus = 1;
	case '+': break;
	default: (*_Iungc)(c,_Isfil);
	}
while ((dval=_Idigt(c=((*_Igetc)(_Isfil)), numbase ) ) >= 0 && numdig++ < length)
	n = n*numbase + dval;
(*_Iungc)(c,_Isfil);
if (numdig == 0)
	return (-1);
if (iptr == 0)
	return (0);
*iptr = minus ? -n : n;
return (1);
}

_Idigt (x, base)
{
switch (x)
	{
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
		return(x-'0');
	case '8':
	case '9':
		if (base > 8)
			return(x - '0');
	case 'a':
	case 'b':
	case 'c':
	case 'd':
	case 'e':
	case 'f':
		if (base >10)
			return(x - 'a' + 10);
	case 'A':
	case 'B':
	case 'C':
	case 'D':
	case 'E':
	case 'F':
		if (base > 10)
			return(x-'A' + 10);
	}
return(-1);
}
/*%%%%
_Ilong (dptr, length)
	double *dptr;
	int length;
{
	char temp[75];
	int _Inodg();
	double x;
	double atof();

if (_Isstr(temp, length, _Inodg) < 0)
	return (-1);
x = atof(temp);
if (dptr == 0)
	return (0);
*dptr = x;
return (1);
}
 %%%%%*/

_Isstr (sptr, length, stopf)
	char *sptr;
	int length, (*stopf)();
{
	int ch, initlen, _Inxch();
	extern int _Isfil, (*_Igetc)(), (*_Iungc)();

initlen = length;
if ((ch=_Inxch()) < 0)
	return (-1);
(*_Iungc)(ch,_Isfil);
while (!((*stopf)(ch=(*_Igetc)(_Isfil))) && length-- > 0)
	if (sptr != 0)
		*(sptr++) = ch;
if (ch >= 0)
	(*_Iungc)(ch,_Isfil);
if (length == initlen)
	return (-1);
if (sptr == 0)
	return (0);
*sptr = '\0';
return (1);
}

_Iestr (c)
char c;
{
if (_Ispce(c)) return (1);
if (c == '\0') return (1);
return (0);
}
_Ierr (message, a, b, c, d, e)
char message[];
	{
	printf("ERROR ");
	printf(message, a, b, c, d, e);
	cputc('\n');
	cexit();
	}
char _Iendm[128] {0};
_Imtab (formatp)
char **formatp;
{
/* make up special table of string ending characters */
int i, normal;
char ch;
/* normally all characters end string except those listed */
normal = 1;
if (**formatp == '^')
	{normal = 0; (*formatp)++;}
for (i= 0; i < 128; i++)
	_Iendm[i] = normal;
while ((ch = *((*formatp)++)) != ']')
	_Iendm[ch] = !_Iendm[ch];

}

_Inxch ()
/* returns next character which is not _Ispce */
{
	extern int _Isfil, (*_Igetc)();
        int ch;
while ((ch = (*_Igetc)(_Isfil)) > 0 && _Ispce(ch));
if  (ch > 0)
	return (ch);
return (-1);
}

_Ispce (c)
char c;
{
switch (c)
	{
	case ' ':
	case '\n':
	case '\t': return(1);
	}
return(0);
}

_Ispnd (ch)
char ch;
{
return (_Iendm[ch] > 0);
}

char *_Iinpt;
int (*_Igetc)(), (*_Iungc)();
_Igstr ()
{
extern char *_Iinpt;
return (*_Iinpt++);
}

_Iungs(ch)
{
extern char *_Iinpt;
*--_Iinpt = ch;
}
