struct { int integ; };

out2(loc)
int *loc;
{
	return(*loc>>16);
}

out3(loc)
int *loc;
{
	return(*loc>>8);
}

out4(loc)
int *loc;
{
	return(*loc);
}

in2(loc, conten)
char *loc;
{
	*loc++ = conten>>8;
	*loc = conten;
}
in3(loc, conten)
char *loc;
{
	*loc = conten>>16;
	in2(loc+1, conten);
}

in4(loc, conten)
int *loc;
{
	*loc = conten;
}
