/**********************************/

/* utility routines for unix */

out2(loc)
char *loc;
{
	return(*loc<<8 | (*(loc+1)&0377));
}

out3(loc)
{
	return(out2(loc+1));
}

out4(loc)
{
	return(out2(loc+2));
}

in2(loc, conten)
char *loc;
{
	*loc++ = conten>>8;
	*loc = conten;
}

in3(loc, conten)
char *loc;
{
	*loc = conten<0 ? -1 : 0;
	in2(loc+1, conten);
}

in4(loc, conten)
char *loc;
{
	*loc = *(loc+1) = conten<0 ? -1 : 0;
	in2(loc+2, conten);
}
