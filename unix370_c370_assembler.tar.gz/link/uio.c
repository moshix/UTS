int urnleft	0;

uread(fd, loc, xcount)
{
	register n, count;
	static char urbuf[80];
	static int reclen;

 if(xcount < 0) {printf("Bad read count\n");cexit();}
	count = xcount;
	do {
		n = min(urnleft, count);
		move(&urbuf[reclen-urnleft], loc, n);
		loc =+ n;
		count =- n;
		urnleft =- n;
		if(urnleft  <= 0) {
			if ((n = cread(urbuf, &urbuf[1], 80, fd)) <= 0)
				return(xcount-count);
			else 
				reclen = urnleft = n;
		}
	} while(count);
	return (xcount);
}

int uwcount;
char uwbuf[80];

uwrite(fd, loc, count)
{
	register n;
/*/*/
 if(count<0){printf("Bad write count\n");cexit();}
	do {
		n = min(count, 80-uwcount);
		move(loc, &uwbuf[uwcount], n);
		loc =+ n;
		count =- n;
		uwcount =+ n;
		if(uwcount >= 80) {
			uwcount = 0;
			cwrite(uwbuf, &uwbuf[1], 80, fd);
		}
	} while(count);
}

char iozer[79];

uclose(fd)
{
	uwrite(fd, iozer, 79);
}

min(a,b)
{
	return(a>b?b:a);
}

move(a, b, n)
char  *a, *b;
{
	while (n--) *b++ = *a++;
}
