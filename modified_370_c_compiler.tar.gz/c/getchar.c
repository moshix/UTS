int numb 0;
char getchar() {
	static int i;
	static char c, buffer[150];
	while (numb == 0) {
		i = 0;
		c = 'a';
		while (c != '\n') {
			if (read(0,&c,1) != 1) return('\0');
			buffer[numb++] = c;
			}
		buffer[numb] = '\0';
		printf("****** %s",buffer);
		}
	numb--;
	return(buffer[i++]);
	}
