#
struct optab {
	int tabdeg1;
	int tabtyp1;
	int tabdeg2;
	int tabtyp2;
	char *tabstring;
};
struct table {
	int tabop;
	struct optab *tabp;
};

struct optab cctabop[] {




# define cc60	&cctabop[0]

 63,0,  4,0,	0,
 63,4,  4,0,	0,
 63,5,  4,0,	0,
 63,4,  4,4,	0,
 63,5,  4,5,	"F20\tltBFr\tZ,Z\n",
 63,0,  16,1,	0,
 63,4,  16,5,	0,
 63,5,  16,5,	"F20\tcBF\tZ,A2\n",
 63,0,  84,1,	0,
 63,4,  84,4,	0,
 63,4,  84,5,	"F00S05\tcBF\tZ,#2(R1)\n",
 63,0,  20,0,	"F00S04\tcr\tR,R1\n",
 63,0,  63,0,	0,
 63,4,  63,4,	0,
 63,4,  20,4,	0,
 63,5,  20,5,	0,
 63,5,  63,5,	"S02F20\tcBF\tZ,T\n",


0,0,0,0,0,
# define rest	&cctabop[18]

 63,0,  63,0,	0,
 63,4,  63,4,	"H00",

0,0,0,0,0};


struct table cctab[] {
	60,	cc60,	
	61,	cc60,	
	62,	cc60,	
	63,	cc60,	
	64,	cc60,	
	65,	cc60,	
	66,	cc60,	
	67,	cc60,	
	68,	cc60,	
	69,	cc60,	
	0,	0,
	};
 