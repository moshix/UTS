int smode;
int peekc;
int peekchar;
int pcmode;
char name[10],*namep;

main(argc, argv) int argc; char **argv; {
auto c,d,snlflg,nlflg,t,m,ssmode,i,itemnbr;
extern cin,cout;
int j;
j=cout;
itemnbr=smode=nlflg=snlflg=ssmode=0;
if (argc>1)
	if ((cin=copen(argv[1],'r'))<0) {
		putchar('?\n');
		cexit(1);
	}
	if (argc > 2)
		if ((cout=copen(argv[2],'w'))<0) {
			printf(j,"?\n");
			cexit(1);
		}
printf("#\n");
printf("struct optab {\n");
printf("	int tabdeg1;\n");
printf("	int tabtyp1;\n");
printf("	int tabdeg2;\n");
printf("	int tabtyp2;\n");
printf("	char *tabstring;\n");
printf("};\n");
printf("struct table {\n");
printf("	int tabop;\n");
printf("	struct optab *tabp;\n");
printf("};\n\n");

namep = &name[0];
if (getchar() != '$') {
	printf("No table name\n");
	cexit(1);
}

for (i=0; i<8 && (c=getchar()) != '\n'; i++) 
	name[i]=c;
printf("struct optab %sop[] {\n", namep);

loop:

c=getc();
if ((c != '\n') && (c != '\t')) nlflg=0;
if (ssmode && c != '%') ssmode=0;

switch (c) {

case '\0':
	cexit(0);
case ':':
	if (itemnbr != 0) {
		printf("\n0,0,0,0,0,");
		itemnbr++;
	}
	printf("\n# define ");
	while ((c=getc()) != ':')
		putchar(c);
	printf("	&%sop[%d]\n", namep,itemnbr);
	goto loop;
case 'F':
case 'S':
case 'H':
	putchar(c);
	if (c == 'F')
		if ((c=getc()) == 'R') {
			putchar(c);
			goto loop;
		}
		else
			peekc=c;

subtre:

	snlflg=1;
	t=0;

l1:

	switch (c=getc()) {

	case '*':
		t =| 1;
		goto l1;
	case 'S':
		t =| 2;
		goto l1;
	case '1':
		t =| 4;
		goto l1;
	case '2':
		t =| 010;
		goto l1;
	case 'X':
		t =| 020;
		goto l1;
	}

	peekc=c;
	putchar(t/8+'0');	
	putchar((t&07)+'0');	
	goto loop;
		/* end of cases for F,S,H */

case 'B':
	putchar(c);
	if ((c=getc()) == 'F')
		putchar(c);
	else
		peekc=c;
	goto loop;

case '\t':
	if (nlflg)
		nlflg=0;
	else
		printf("\\t");
	goto loop;

case '\n':
	if (!smode) {
		putchar('\n');
		goto loop;
	}
	if (nlflg) {  /* have just seen \n\n */
		nlflg=0;
		printf("\",\n");
		smode=0;
		pcmode=0;
		goto loop;
	}
	if (!snlflg) 
		printf("\\n");
	snlflg=0;
	nlflg=1;
	goto loop;
case '%':
	pcmode=1;

loop2:

	itemnbr++;

loop1:

	switch(c=getc()) {
	case ',':
		putchar(' ');
		goto loop1;
	case 'z':
		m=4;
		t=flag();
		goto pf;
	case 'c':
		t=0;
		m=8;
		goto pf;
	case 'r':
		m=12;
		t=flag();
		goto pf;
	case 'a':
		m=16;
		t=flag();
		goto pf;
	case 'e':
		m=20;
		t=flag();
		goto pf;
	case 'n':
		m=63;
		t=flag();

pf:

		if ((c=getc()) == '*')
			m =| 0100;
		else 
			peekc=c;
		printf(" %d,%d,",m,t);
		goto loop1;
	case '\n':
		if ((c=getc()) == '%') {
			printf("	0,\n");
			goto loop2;
		}
		else {
			peekc=c;
			printf("	\"");
			ssmode=1;
			nlflg=1;
			smode=1;
			snlflg=0;
			goto loop;
		}
	}
	putchar(c);
	goto loop1;
			/* end case '%' */
case '[':
	if ((c=getc()) == ']') {
		printf("[]");
		while(putchar(getc()));
		peekc='\0';
	}
	else {
		peekc=c;
		putchar('[');
	}
	goto loop;
}			/* end of big switch */
putchar(c);
goto loop;
}			/* end of main function */


getc() {
auto t;

if (peekc) {
	t=peekc;
	peekc=0;
}
else {
	if (peekchar) {
		t=peekchar;
		peekchar=0;
	}
	else 
		t=getchar();
}
if (!pcmode) {
	if (t == '/') 	/* process a comment */
		while ((t=getchar()) != '\n');
	if (t == '\n')
		while ((peekchar=getchar()) == '/')
			while (getchar() != '\n');
}
return(t);
}

flag() {
register c,f;
f=0;

l1:

switch (c=getc()) {

case 'w':
	f=1;
	goto l1;
case 'i':
	f=2;
	goto l1;
case 'b':
	f=3;
	goto l1;
case 'f':
	f=4;
	goto l1;
case 'd':
	f=5;
	goto l1;
case 's':
	f=6;
	goto l1;
case 'p':
	f =+ 16;
	goto l1;
}
peekc=c;
return(f);
}
