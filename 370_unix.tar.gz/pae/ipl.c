 /* ipl program */

struct {
	int magic;
	int tsize;
	int dsize;
	int fill[5];
} header;

char magic[4] {0107, 0360, 0, 040};

main(argc, argv)
char **argv;
{
	int fd, area, size;
	if(argc != 2) {
		printf("arg count\n");
		cexit(1);
	}
	fd = copen(argv[1], 'r');
	uread(fd, &header, 32);
	if(header.magic != magic[0].magic) {
		printf("not an a.out file\n");
		cexit(2);
	}
	size = header.tsize + header.dsize;
	area = calloc(size + 16, 1);
	uread(fd, area, size);
	loadit(area, size);
	/* should not return */
}
#include	"../link/uio.c"
