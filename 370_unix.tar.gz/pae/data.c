#

 /* all the data for the system */

#define extern		/* we don't want it to be external this time */

#include "../manifest.h"
#include "../param.h"
#include "../370.h"
#include "../proc.h"
#include "../inode.h"
#include "../systm.h"
#include "../text.h"
#include "../buf.h"
#include "../file.h"
#include "../filsys.h"

char buffers[NBUF][BLKSIZE];
