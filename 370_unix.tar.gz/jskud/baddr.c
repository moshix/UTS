main(argc,argv)
int argc;
char **argv;
{
	int cc,hh,xr,tmp;
	char *cp,c;

	cp = argv[1];
	tmp = 0;
	while(c = *cp++) switch(c){
		case '0':case '1':case '2':case '3':case '4':
		case '5':case '6':case '7':case '8':case '9':
			tmp = tmp*16 + c - '0';
			break;
		case 'a':case 'b':case 'c':case 'd':case 'e':
		case 'f':
			tmp = tmp*16 + c - 'a' + 10;
			break;
	}

	xr = tmp%12 + 1;
	tmp = tmp/12+1; /* skip first record and track */
	hh = tmp%12;
	cc = tmp/12;
	printf("%x %x %x\n",cc,hh,xr);
}
