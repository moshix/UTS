#include "../conf.h"
#include "../manifest.h"
#include "../param.h"
#include "../user.h"

/*
 * Memory special file
 * minor device 0 is physical memory
 * minor device 1 is EOF/RATHOLE
 */

mmread(dev)
{
	char *cp;
	extern char *memlim;
	if(dev.d_minor == 1) return;
	do{
		cp = u->u_offset;
		if(cp > memlim) return;
	}while(u->u_error == 0 && passc(*cp) >= 0);
}

mmwrite(dev)
{
	char c;
	extern char *memlim;
	if(dev.d_minor == 1){
		u->u_base =+ u->u_count;
		u->u_offset =+ u->u_count;
		u->u_count = 0;
		return;
	}
	while(	u->u_offset <= memlim &&
		(c = cpass()) >= 0 &&
		u->u_error == 0) *u->u_offset = c;
}
