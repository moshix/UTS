main()
{
	int i,n;
	extern int fout;
	char buf[512];
	for(;;){
		fout = open("/dev/tty0",2);
		printf("\n\nUnix/370\n");
		i=0;
		while((n=read(fout,buf,512)) && i++ < 20)
			write(fout,buf,n);
		printf("\nBye now! Y'all come back now, hear?\n");
		close(fout);
	}
}
