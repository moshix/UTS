#include "../370.h"
#include "../param.h"
#include "../buf.h"
#include "../tty.h"

extern struct cblock cfree[];
extern struct cblock *cfreelist;

getc(q)
struct clist *q;
{
	struct cblock *cbp;
	char *cp,c;
	int sps;
	if(q->c_cc == 0) return(-1);
	sps = stnsm(~ALLINT);
	q->c_cc--;
	cp = cfree;	/* kludge */
	cbp = q->c_cf - (q->c_cf - cp) % sizeof *cbp;
	cp = q->c_cf++;
	if(q->c_cf > &cbp->info[NINFO-1] || q->c_cc == 0 ){
		q->c_cf = &cbp->c_next->info[0];
		cbp->c_next = cfreelist;
		cfreelist = cbp;
	}
	c = *cp;
	setsm(sps);
	return(c);
}

putc(c,q)
char c;
struct clist *q;
{
	struct cblock *cbp;
	char *cp;
	int sps,rc;
	rc = 0;
	sps = stnsm(~ALLINT);
	if(q->c_cc == 0) {
		if((cbp = cfreelist) == 0){
			rc--;
			goto out;
		}
		cfreelist = cfreelist->c_next;
		q->c_cc = 1;
		q->c_cf = q->c_cl = &cbp->info[0];
		cbp->info[0] = c;
	} else {
		q->c_cc++;
		cp = cfree;	/* kludge */
		cbp = q->c_cl - (q->c_cl - cp) % sizeof *cbp;
		cp = ++q->c_cl;
		if(cp > &cbp->info[NINFO-1]){
			if((cbp->c_next = cfreelist) == 0){
				rc--;
				goto out;
			}
			cfreelist = cfreelist->c_next;
			cbp = cbp->c_next;
			cp = q->c_cl = &cbp->info[0];
		}
		*cp = c;
	}
out:	setsm(sps);
	return(rc);
}
