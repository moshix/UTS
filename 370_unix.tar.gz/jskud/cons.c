#
#define	CSW	64
conintr(majmin)
int majmin;
{
	extern char consbusy;
	char *p;
	p = CSW + 4;
	if(*p & 4)
		consbusy = 0;
}

conswrt()
{
	char c;
	while((c = cpass()) >= 0) putchar(c);
}
