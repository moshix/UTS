#
/*
 * input/output lookup table for interupts... not very elegant, but
 * neither is working down to the wire... sorry...
 */

#include	"../dsk.h"

#define	MAJOR	256
#define DISK195	#195
#define	DISK222	#222
#define	CONSOLE	#009
#define TRMBASE #030

int	iolkptab[]
{
	DISK222,	&dskintr,	0*MAJOR+0,
	DISK195,	&dskintr,	1*MAJOR+0,
  	CONSOLE,	&conintr,	0*MAJOR+0,
	TRMBASE+0,	&trmintr,	2*MAJOR+0,
	TRMBASE+1,	&trmintr,	2*MAJOR+1,
	TRMBASE+2,	&trmintr,	2*MAJOR+2,
	TRMBASE+3,	&trmintr,	2*MAJOR+3,
	TRMBASE+4,	&trmintr,	2*MAJOR+4,
	TRMBASE+5,	&trmintr,	2*MAJOR+5,
	TRMBASE+6,	&trmintr,	2*MAJOR+6,
	TRMBASE+7,	&trmintr,	2*MAJOR+7,
	TRMBASE+8,	&trmintr,	2*MAJOR+8,
	TRMBASE+9,	&trmintr,	2*MAJOR+9,
	TRMBASE+10,	&trmintr,	2*MAJOR+10,
	TRMBASE+11,	&trmintr,	2*MAJOR+11,
	TRMBASE+12,	&trmintr,	2*MAJOR+12,
	TRMBASE+13,	&trmintr,	2*MAJOR+13,
	TRMBASE+14,	&trmintr,	2*MAJOR+14,
	TRMBASE+15,	&trmintr,	2*MAJOR+15,
/*	 not yet available...
 *	#00c,	&crdintr,	-1,
 *	#00d,	&punintr,	-1,
 *	#00e,	&prtintr,	-1,
 */
	-1,	&nointr,	-1
};

int	(*bdevsw[])()
{
  &dskopen,  &nulldev,  DISK222,  &dskstrat,  &root_tab,
  &dskopen,  &nulldev,  DISK195,  &dskstrat,  &mnt_tab,
	0
};

int	(*cdevsw[])()
{
	&nulldev, &nulldev, CONSOLE, &nulldev, &conswrt, &nulldev, /* cons */
	&nulldev, &nulldev ,    0, &mmread , &mmwrite , &nodev   , /* mem */
	&trmopen,&trmclose,TRMBASE,&trmread,&trmwrite,&trmsgtty, /* terms */
	0
};
int nchrdev;
int nblkdev;

int	root_tab[]
{
	0,  0,  0,  0,  &root_dsc,  0
};

int	mnt_tab[]
{
	0,  0,  0,  0,  &mnt_dsc,  0
};

struct	devdesc	root_dsc;
struct	devdesc	mnt_dsc;

int	dskdesc[]
{
	12,	12,	353,	679,	140
};
