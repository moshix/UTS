/*
 * Location of the users' stored
 * registers relative to user stack pointer (R13).
 * Usage is u->u_arsp[XX].
 */
#define	R0	(3)
#define	R1	(4)
 /* while R2-R12 are on the stack at the location that the
  * prologue macro of trap(...) stored them, the location relative to R0, etc.
  * depends on the size of automatic storage of trap(...).  You don't need
  * them anyway, except for exec (see u_orega)
  */
#define	R13	(0)	/* this is also the user stack pointer if
			 * the process is not in emulate mode */
#define	R14	(1)
#define	R15	(2)
#define	RPS	(5)	/* this is the forst word of the psw */
#define	RPC	(6)	/* this is the second word of the psw */

