/*
 * tunable variables
 */

#define	NBUF	60		/* size of buffer cache */
#define	NINODE	100		/* number of in core inodes */
#define	NFILE	100		/* number of in core file structures */
#define	NMOUNT	2		/* number of mountable file systems */
#define	NEXEC	3		/* number of simultaneous exec's */
#define MAXMEM	256		/* max core per process in units of pages */
#define SSIZE	1		/* initial stack size in pages */
#define SINCR	1		/* increment of stack in pages */
#define	NOFILE	15		/* max open files per process */
#define	CANBSIZ	256		/* max size of typewriter line */
#define MAXMSG 128		/* max size of message to ourselves */
 /* for pugs
#define	CMAPSIZ	100		/* size of core allocation area */
 /* for pugs
#define	SMAPSIZ	100		/* size of swap allocation area */
#define	NCALL	4		/* max simultaneous time callouts */
#define	NPROC	50		/* max number of processes */
#define	NTEXT	40		/* max number of pure texts */
#define	NCLIST	100		/* max total clist size */
#define	NINFO	60		/* number of chars per cblock */
#define	HZ	1		/* Ticks/second of the clock */
#define NTRMS	16

/*
 * priorities
 * probably should not be
 * altered too much
 */

#define	PSWP	-100
#define	PINOD	-90
#define	PRIBIO	-50
#define	PPIPE	1
#define	PWAIT	40
#define	PSLEP	90
#define	PUSER	100
