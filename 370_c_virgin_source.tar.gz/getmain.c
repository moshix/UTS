/* For use with OS only */
struct fb {int size; char *next;} *
getmain(min,max)
	{
	static int ptr[2];
	static int rtr[2];
	ptr[1] = (nargs(2)==1) ? min : max;
	ptr[0] = min;

	asm("   getmain vc,la=$2,a=$3 ");
	asm("   n     15,=x'000000ff'  ");
	asm("   l     0,$3        ");
	asm("   l     1,$3+4      ");
	asm("   ltr   15,15   ");
	asm("   bz    ok    ");
	asm("   l     0,=f'-1' ");
	asm("ok  st    0,$3+4   ");
	asm("    st    1,$3   ");

	return(rtr);
}
