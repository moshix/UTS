# include "iodef.c"
extern int _gate;
cgate()
{
	extern char *_definp, *_defout, *_deferr;
	extern int cexit();
if (_gate) return;
_gate = &cexit;
if (_fbuffp[0] == 0)
	copen ( _definp, 'r');
if (_fbuffp[1] == 0)
	copen( _defout,'w');
if (_fbuffp[2] == 0)
	copen( _deferr, 'w');
}
