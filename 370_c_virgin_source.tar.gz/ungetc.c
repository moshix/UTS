# include "iodef.c"
ungetc (c, fnin)
{
struct iobuf *fp;
extern int cin, _gate; int fn;
if (_gate == 0) cgate();
fn = nargs(2) > 1 ? fnin : cin;
/* push back onto input */
if (fn < 0 || fn >NFILES || (fp = _fbuffp[fn]) == 0)
	ermsg("UNGETC: no file %d\n",fn);
if (fp->out > 0)
	ermsg("UNGETC: attempt to push back output file %d\n",fn);
if (fp->cp <= fp->buf)
	ermsg("UNGETC: buffer full file %d",fn);
if (fp->nchars < 0)
	return (c);
*--fp->cp = c;
fp->nchars++;
return (c);
}
