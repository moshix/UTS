genreg (regno, ndecl)
{
/* this returns the value of register regno to a subroutine
   that had ndecl paramters */
int **mysave;
/* find my own save area */
mysave = &ndecl;
mysave++;
/* now find his save area */
return ( *( mysave[12]+ndecl+regno) );
}
