/* default names */
char *_definp "SYSIN";
char *_defout "SYSPRINT";
char *_deferr "SYSPRINT";
