_access(name,fn,dir)
  char *name;
{
static char ddn[20];
char line[40],  *jfcb;
 int rd;
if(_scomp(name, "TERMINAL")== '=')
  return(name);
_pad(line,name,35);
if (_isddn(line))
  {
  _pad(ddn,name,8);
  ddn[9]=0;
  return(ddn);
  }
if (jfcb= _isdsn(line))
  {
  _pad(ddn,jfcb,8);
  ddn[9]= 0;
  return(ddn);
  }
if (dir == 'r' || dir == 'R') return(0);
_pad(line, "C##0,vi,dsname=",15);
_pad(line+15, name,24);
line[3] = '0'+fn;
line[39] = 39;
 /* 39 is hex 27 which is the character to end parameter string */
_pad(ddn,"C##0",8);
ddn[3] = '0'+fn;
ddn[9] = 0;
rd = _ddef(line);
return( rd? ddn : 0);
}
_pad(b, s, n)
 char *b, *s;
{
int i, c;
for(i=0; i<n && (c= s[i]); i++)
 b[i] = _lower(c) ? c + 'A' - 'a' : c;
while (i<n)
 b[i++] = ' ';
}
_lower (c)
{
switch(c)
 {
 case 'a': case 'b': case 'c': case 'd': case 'e':
 case 'f': case 'g': case 'h': case 'i': case 'j':
 case 'k': case 'l': case 'm': case 'n': case 'o': /* hmm */
 case 'p': case 'q': case 'r': case 's': case 't':
 case 'u': case 'v': case 'w': case 'x': case 'y': case 'z':
  return(1);
     }
return(0);
}
_scomp(s,t)
 char *s, *t;
{
int c,d;
while ((c = *s++) == (d = *t++))
 if (c==0)
  return('=');
return(c>d ? '>' : '<');
}
