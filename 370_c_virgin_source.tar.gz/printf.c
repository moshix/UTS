char  *_ptrbf, *_ptrst, *__fmt;
printf(a1,a2,a3,a4, z1, z2, z3, z4, z5, z6, z7, z8, z9){
auto char  c, *s,  adj, *ptr,*p, buf[30];
extern cputc(),_putstr(), cout;
auto int  *adx, x, n, m, width, prec,i, padchar, fd;
double *dblptr;
char (*f)();
_ptrbf = buf;

fd=cout;
adx = &a1;
f = cputc;
if (a1 == -1)
  {
  f = _putstr;
  _ptrst = a2;
  adx =+ 2;
  }
else if (a1 >= 0 && a1 <= 9)
  fd = *adx++;
__fmt = *adx++;


while( c = *__fmt++ ){
   if(c != '%') (*f)(c,fd);
   else { x = *adx++;
      if( *__fmt == '-' ){ adj = 'l';  __fmt++; }
      else adj = 'r';
   padchar = (*__fmt=='0') ? '0' : ' ';
      width = __conv();
      if( *__fmt == '.'){++__fmt; prec = __conv();}
      else prec = -1;

	s = 0;
   switch ( c = *__fmt++ ) {
	case 'u': case 'U':
	case 'd': case 'D':
		__prnt10(x);
		break;
     case 'o':
     case 'O':
	_prnt8(x); break;
     case 'x':
     case 'X':
	_prntx(x); break;
      case 'S':
     case 's':    s=x;
        break;
     case 'C':
     case 'c':   *_ptrbf++ = x&0377;
         break;
     case 'E':
     case 'e':
     case 'F':
     case 'f':
      dblptr = adx-1;
      adx =+ 1;
      ftoa (*dblptr, s=buf, prec, c);
      prec = -1;
     break;
     default:   (*f)(c,fd);
         adx--;
   }
   if (s == 0)
    {*_ptrbf = '\0'; s = buf;}
   n = _clenf (s);
   n = (prec<n && prec >= 0) ? prec : n;
   m = width-n;
	if (adj == 'r')
		{
		if (padchar=='0' && s[0] == '-')
			{
			n--;
			(*f)(*s++,fd);
			}
		while (m-- > 0)
			(*f)(padchar,fd);
		}
   while (n--) (*f)(*s++,fd);
   while (m-- > 0) (*f)(padchar,fd);
   _ptrbf = buf;
   }
}
if(a1 == -1) (*f)('\0',fd);
}


__conv()
{
auto c,n;
n = 0;
while( ((c = *__fmt++) >= '0') && (c<='9')) n = n*10+c-'0';
__fmt--;
return(n);
}

_putstr(chr,str){
*_ptrst++ = chr;
return;
}
__prnt10(n)
{
int pstk[10], *ps;
if (n>=0) n= -n;
else *_ptrbf++ = '-';
ps = pstk;
if (n==0)
  *ps++ = '0';
else
while (n)
 {
 *ps++ = '0' - (n%10);
  n = n/10;
   }
while (ps>pstk)
  *_ptrbf++ = *--ps;
}

_prnt8 (n)
{ /* print in octtal */
int p, k, sw;
if (n==0) {*_ptrbf++ = '0'; return;}
sw = 0;
for (p=15; p >= 0; p =- 3)
  if ((k = (n>>p)&07) || sw)
   {
    *_ptrbf++ = '0' + k;
     sw = 1;
     }
}
_prntx (n)
{
	int d,a;
	if (a = n>>4)
		_prntx ( a & 0177777);
	d = n&017;
	*_ptrbf++ =  d > 9 ? 'A'+d-10 : '0' + d;
}

