# include "iodef.c"

cflush (fn)
{
struct iobuf *fp;
if (fn < 0 || fn > NFILES || _fbuffp[fn] == 0)
	return;;
fp = _fbuffp[fn];
if (fp->nchars == 0)
	return;
if (fp->out > 0)
	inout (fp->dd, "W   ", fp->cp=fp->buf, fp->nchars);
fp->nchars = 0;
}
