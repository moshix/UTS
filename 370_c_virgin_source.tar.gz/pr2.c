# include "prh.c"
struct symtab stab[symsiz];
char sbf[SBSIZE];
