ermsg(format, data)
char *format;
{
extern int cout;
printf (format, data);
cclose(cout);
cexit(8);
}
