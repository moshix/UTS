# include "iodef.c"

cread (ptr, ptrp1, numb, fn)
{
int need, k, size, start;
char buff[804], *pb, *sp;
if (fn < 0 || fn >NFILES || _fbuffp[fn] == 0)
	ermsg ("CREAD: file %d not opened\n", fn);
sp = start = ptr;
size = ptrp1 - ptr;
need = size*numb;
if (need <800)
	pb = buff;
else
	pb = calloc(need+4, 1);
pb=+4;
k = inout(_fbuffp[fn]->dd, "R   ", pb, need);
for(k=0; k<need; k++)
	sp[k] = pb[k];
if (need>= 800)
	cfree(pb-4,need+4,1);
return (numb);
}
