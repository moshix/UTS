# include "iodef.c"

cexit (returncode)
{
int i;
extern int _gate;
if (_gate == 0) cgate();
for (i=0; i<NFILES; i++)
	cclose(i);
_cstop (nargs(1) == 1 ? returncode : 0);
}
