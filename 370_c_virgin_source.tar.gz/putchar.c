putchar(c)
{
extern int cout;
return (cputc(c,cout));
}
