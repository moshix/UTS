int _gate 0;
int _gates 0;
