# define NFILES 10
struct iobuf {char dd[20], *cp; int out, nchars; char buf[612];};
struct iobuf *_fbuffp[NFILES];

copen (name, direction, options)
char *name, *options; int direction;
{
int fn, n, i;
char *optstr, optdef[4];
struct iobuf *fp;
extern int _gate;
if (_gate==0) cgate();
for (fn = 0; _fbuffp[fn] != 0 && fn < NFILES; fn++);

if (fn >= NFILES)
	return (-1);

/* special choices now are
    e - edit lower case and tabs from output
    b - begin each line with blank
    n - don't begin each line with blank
   */
optstr = nargs(3) == 3 ? options : "";
if (optstr >= 0 && optstr < 512)
	{optstr = optdef; optdef[0] = i = options; optdef[1] = 0;}
_fbuffp[fn] = fp = calloc(612+20+4+4+4,1);
name = _access(name,fn,direction);
if (name==0)
	return(-1);
/* name must be blank padded in dd field */
for(i=0; i<20; i++)
  {
  fp->dd[i] = *name ? *name++ : ' ';
  }

fp->nchars = 0;
fp->out = (direction == 'w' || direction == 'W') ? 1 : 0;
fp->cp = fp->buf + (fp->out ? 0 : 100);
if (fp->out > 0)
while (*optstr)
	switch (*optstr++)
		{
		case 'e':
		case 'E':
			fp->out =| 2;
			break;
		case 'b':
		case 'B':
			fp->out =| 04;
			break;
		case 'n':
		case 'N':
			fp->out =& (~04);
			break;
		}
return (fn);
}
