char
*gets(s,n)
char *s;
{
int c, fn;
char *p;
	extern int cin;
p = s;
fn = nargs(2) > 1 ? n : cin;
while ((c=cgetc(fn)) != '\0' && c != '\n')
  *s++ = c;
*s = '\0';
while (*--s == ' ')
	*s = '\0';
return (c ? p : 0);
}
