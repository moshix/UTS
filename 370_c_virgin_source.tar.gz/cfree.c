struct fb {
	int	size;
	char	*next;
};

extern int _freech[];
cfree(aptr)
char *aptr;
{
	char *ptr, *cp, *np;

	ptr = aptr-4;
	cp = _freech;
	while (((np = cp->next) < ptr) && (np > 0))
		cp = np;
	if (ptr+ptr->size == np) {
		ptr->size =+ np->size;
		ptr->next = np->next;
		np = ptr;
	} else
		ptr->next = np;
	if (cp+cp->size == ptr) {
		cp->size =+ ptr->size;
		cp->next = ptr->next;
	} else
		cp->next = ptr;
}
