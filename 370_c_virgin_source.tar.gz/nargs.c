# define ARCOUNT 1
nargs(x)
{
int *r12;
r12 = genreg(12, 1);
/* ARCOUNT is the number fo the register containing the
   length of the arguments, now 1 */
return(r12[x+ARCOUNT]>>2);
}
