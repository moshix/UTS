# include "iodef.c"

cwrite (ptr, ptrp1, numb, fn)
{
int need, k, size, start;
char buff[804], *pb, *sp;
if (fn < 0 || fn >NFILES || _fbuffp[fn] == 0)
	ermsg ("CWRITE: file %d not opened\n", fn);
sp =start = ptr;
size = ptrp1 - ptr;
need = size*numb;
if (need <800)
	pb = buff;
else
	pb = calloc(need+4, 1);
pb =+ 4;
for(k=0; k<need; k++)
	pb[k] = sp[k];
k = inout (_fbuffp[fn]->dd, "W   ", pb, need);
if (need>= 800)
	cfree(pb-4, need+4,1);
return (numb);
}
