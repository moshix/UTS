# include "iodef.c"

cgetc (fl)
{
struct iobuf *fp;
int fn;
extern int _gate, cin;
if (_gate ==0) cgate(); /* open files first time */

fn = nargs(1) > 0 ? fl : cin;
if (fn < 0 || fn >NFILES || (fp = _fbuffp[fn]) == 0)
	ermsg("CGETC: no file %d\n",fn);
if (fp->out > 0) ermsg ("CGETC: reading file %d open for write\n",fn);
if (fp->nchars == 0)
	{
	fp->nchars = inout(fp->dd, "R   ", fp->cp=fp->buf+100,512);
	if (fp->nchars > 0)
		fp->cp[fp->nchars++] = '\n';
	}
if (fp->nchars-- > 0)
	return ( *(fp->cp)++ );
else
	{
	fp->nchars = -1;
	return ('\0');
	}
}

int cin 0;
