# include "iodef.c"

cclose (fn)
{
char *ddn;
if (fn < 0 || fn > NFILES || _fbuffp[fn] == 0)
	return;
cflush (fn);
inout (ddn=_fbuffp[fn]->dd, "C   ");
if (_prefix(ddn, "C##"))
	_rel(ddn);
if (_prefix(ddn, "$$$"))
	_rel(ddn);
cfree (_fbuffp[fn],612+20+4+4+4,1);
_fbuffp[fn] = 0;
}
_prefix(s,t)
	char *s, *t;
{
while (*s++ == *t++)
	if (*t==0)
		return(1);
return(0);
}
