getchar()
{
	extern int cin;
return(cgetc(cin));
}
