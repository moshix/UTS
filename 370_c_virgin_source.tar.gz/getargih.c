# define LPARM 100
char *_argv_[20];
_gtargs()
{
static char pbuff[LPARM+2];
int nchar, argc, i;
char *parm, **parmlist, *newp;
	extern char *_definp, *_defout;
/* TSS only ... */
	extern char *_deferr, *_defter;
	extern int _tabflg, _gate;
	char b[10];
	/* ... */
printf(-1, b, "%cTABS", 4);
_tabflg = _deflt(b+1);
_definp = _defout = _deferr = _defter;
_gate = 0;
parmlist = genreg (3,0); /* find register 1 which was copied to 3 */
if (parmlist==0) return(0);
parm = *parmlist; /* find actual address of parameter string */
/* this won't cross compile ...
parm =& 077777777; /* get 24-bit address */
i = parm;
i = i<<8;
i = i>>8;
parm = i;
/* next lines for OS ... 
nchar = parm[0]*256+parm[1];
parm =+ 2; /* actual start of characters */
 /* next lines for TSS  ... */
nchar = parm[-1];
 /*  ... */
if (nchar==0)
	return (0);
newp = pbuff;
if (nchar > LPARM) nchar= LPARM;
for (i=0; i<nchar; i++)
   *newp++ = *parm++; /*copy list to known space*/
*newp++ = ' ';
*newp = '\0'; /* mark end */
argc = 0;
parm= pbuff;
while (1)
	{
	while (*parm == ' ')
		*parm++ = 0;
	if (*parm == 0)
		return (argc);
	/* is it an i-o diversion ? */
	if (*parm == '<')
		_definp = parm+1;
	else if (*parm == '>')
		_defout = parm+1;
	else
		/* normal argument */
		_argv_[argc++] = parm;
	while (*parm != ' ')
		parm++;
	}
}
