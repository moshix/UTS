# include "iodef.c"

cputc (ch, fl)
{
struct iobuf *fp;
int fn;
extern int _gate, cout;
if (_gate== 0) cgate();
fn = nargs(2) > 1 ? fl : cout;
if (fn < 0 || fn > NFILES || (fp=_fbuffp[fn]) == 0 )
	ermsg ("CPUTC: file %d not opened\n",fn);
if (fp->out == 0)
	ermsg ("CPUTC: file %d opened to read\n",fn);
if ((fp->out&02)  != 0) /* edit mode on output */
	if (ch >= 'a' && ch <= 'z') /* translate to upper case */
		ch =+ 'A'-'a';
if (ch != '\n')
	{
	if (fp->nchars == 0 && (fp->out&04) != 0)
/* fp->out bit 04 is on if carriage control wanted */
		{fp->nchars++; *(fp->cp)++ = ' ';}
	/* should we process tabs ? */
	if (ch == '\t' && (fp->out&02) != 0)
		for (ch = ' '; (fp->nchars==0 || fp->nchars % 8); fp->nchars++)
			*(fp->cp)++ = ' ';
	*(fp->cp)++ = ch;
	if (++(fp->nchars) < 511)
		return (ch);
	}
/* newline or record too long */
if (fp->nchars == 0)
	/* zero length record, add a blank */
	{*fp->cp = ' '; fp->nchars = 1;}
inout (fp->dd, "W   ", fp->cp=fp->buf, fp->nchars);
fp->nchars = 0;
return ('\n');
}

int cout 1;
