# define SBSIZE 20000
# define symsiz 1000
struct symtab {
        char    name[8];
        char    *value;
};
