#
struct optab {
	int tabdeg1;
	int tabtyp1;
	int tabdeg2;
	int tabtyp2;
	char *tabstring;
};
struct table {
	int tabop;
	struct optab *tabp;
};

struct optab regtabop[] {


# define cr104	&regtabop[0]

 8,0,  63,0,	"\tdc\tf'C1'\n",
 16,0,  63,0,	0,
 16,5,  63,0,	"\tdc\ta(A1)\n",


# define cr107	&regtabop[3]

 8,0,  63,0,	"\tdc\tx'Q'\n",


# define cr102	&regtabop[4]

 16,0,  63,0,	"\tb\tA1\n",
 127,0,  63,0,	"F01\tb\t#1(R)\n",


# define cr100	&regtabop[6]

 16,0,  63,0,	0,
 16,0,  63,5,	"\tlfunc\t15,A1\n",
 63,0,  63,0,	0,
 63,0,  63,5,	"F20\tlr\t15,R\n",


# define cr106	&regtabop[10]

 4,0,  63,0,	"\tsr\tR,R\n",
 16,3,  63,0,	"\tsr\tR,R\n\tic\tR,A1\n",
 16,0,  63,0,	"\tl\tR,A1\n",
 16,4,  63,0,	"\tsdr\tFR,FR\n\tle\tFR,A1\n",
 16,5,  63,0,	"\tld\tFR,A1\n",


# define cr32	&regtabop[15]

 16,0,  63,0,	0,
 16,3,  63,0,	"\tlB1\tR,A1\n\tlr\t0,R\n\tO\t0,A2\n\tstB1\t0,A1\n",
 84,0,  63,0,	0,
 84,3,  63,0,	"F01\tlB1\t0,#1(R)\n\tlr\t1,0\n\tO\t1,A2\n\tstB1\t1,#1(R)\n\tlr\tR,0\n",
 127,0,  63,0,	"F01\tlr\t1,R\n\tlB1\tR,#1(1)\n\tlr\t0,R\n\tO\t0,A2\n\tstB1\t0,#1(1)\n",


# define cr35	&regtabop[20]

 16,0,  63,0,	0,
 16,4,  63,0,	"\tla\tR,A1\n",


# define cr36	&regtabop[22]

 16,18,  63,0,	0,
 16,19,  63,0,	"\tl\t1,A1\n\tlB1\tR,0(1)\n",
 63,19,  63,0,	"H01\tsr\t1,1\n\tic\t1,~(R)\n\tlr\tR,1\n",
 63,20,  63,0,	"H01\tsdr\tFR,FR\n\tle\tFR,~(R)\n",
 63,0,  63,0,	0,
 63,21,  63,0,	"H01\tlBF\tZ,~(R)\n",


# define cr37	&regtabop[28]

 63,0,  63,0,	0,
 63,5,  63,0,	"F20\tlcBFr\tZ,Z\n",


# define cr38	&regtabop[30]

 63,0,  63,0,	"F20\tx\tR,=x'ffffffff'\n",


# define cr80	&regtabop[31]

 16,0,  63,0,	0,
 16,5,  63,5,	"S20\tstB1\tZ,A1\n",
 80,0,  63,0,	"S20\tl\t1,A1\n\tstB1\tR,0(1)\n",
 16,0,  63,5,	"S20\tmovfi\tFR,R\n\tstB1\tR,A1\n",
 84,0,  63,5,	"S00F05\tmovfi\tFR,R\n\tstB1\tR,#1(R1)\n",
 127,0,  63,5,	"F03S00\tmovfi\tFR,R\n\tstB1\tR1,#1(R)\n\tlr\tR,R1\n",
 127,0,  20,0,	"F01S04\tstB1\tR1,#1(R)\n\tlr\tR,R1\n",
 127,0,  63,0,	0,
 127,5,  63,5,	"F03S20\tl\t1,T\n\tstB1\tZ,#1(1)\n",


# define cr45	&regtabop[40]

 63,0,  4,0,	"F20",
 63,0,  8,0,	"F20\tsrl\tR,C2\n",
 63,0,  20,0,	"F00S04\tsrl\tR,0(R1)\n",
 63,0,  63,0,	"S02F20\tl\t1,T\n\tsrl\tR,0(1)\n",


# define cr46	&regtabop[44]

 63,0,  4,0,	"F20",
 63,0,  8,0,	"F20\tsll\tR,C2\n",
 63,0,  20,0,	"F00S04\tsll\tR,0(R1)\n",
 63,0,  63,0,	"S02F20\tl\t1,T\n\tsll\tR,0(1)\n",


# define cr40	&regtabop[48]

 63,0,  4,0,	"F00",
 63,0,  16,1,	0,
 63,5,  16,5,	"F20\tOB2\tZ,A2\n",
 63,0,  84,1,	"F00S05\tOB2\tZ,#2(R1)\n",
 63,0,  20,0,	"F00S04\tOr\tR,R1\n",
 63,0,  63,0,	0,
 63,5,  63,5,	"S02F20\tOBF\tZ,T\n",


# define cr47	&regtabop[55]

 63,0,  4,0,	"\tsr\tR,R\n",
 63,0,  16,1,	"F00\tn\tR,A2\n",
 63,0,  84,1,	"F00S05\tn\tR,#2(R1)\n",
 63,0,  20,0,	"F00S04\tnr\tR,R1\n",
 63,0,  63,0,	"S02F00\tn\tR,T\n",


# define cr42	&regtabop[60]

 63,0,  16,1,	"F00\tm\tR-,A2\n",
 63,0,  84,1,	"F00S05\tm\tR-,#2(R1)\n",
 63,0,  20,0,	"F00S04\tmr\tR-,R1\n",
 63,0,  63,0,	"S02F00\tm\tR-,T\n",
 63,5,  16,5,	"F00\tmB2\tFR,A2\n",
 63,5,  63,5,		"S02F00\tmd\tFR,T\n",


# define cr43	&regtabop[66]

 63,0,  16,1,	"F00\tsrda\tR,32\n\td\tR,A2\n",
 63,0,  84,1,	"F00S05\tl\t0,#2(R1)\n\tsrda\tR,32\n\tdr\tR,0\n",
 63,0,  20,0,	"F00S04\tl\t0,R1\n\tsrda\tR,32\n\tdr\tR,0\n",
 63,0,  63,0,	"S02F00\tsrda\tR,32\n\td\tR,T\n",
 63,5,  16,5,	"F00\tdB2\tFR,A2\n",
 63,5,  63,5,	"S02F00\tdBF\tFR,T\n",


# define cr72	&regtabop[72]

 16,3,  63,0,	"S00\tsr\t0,0\n\tic\t0,A1\n\tmr\tR-,0\n\tstc\tR,A1\n",
 16,0,  63,0,	"S00\tm\tR-,A1\n\tst\tR,A1\n",
 84,3,  63,0,	"S00F05\tsr\t0,0\n\tic\t0,#1(R1)\n\tmr\tR-,0\n\tstc\tR,#1(R1)\n",
 84,0,  63,0,	"S00F05\tm\tR-,#1(R1)\n\tst\tR,#1(R1)\n",
 127,3,  63,0,	"F03S00\tl\t1,T\n\tsr\t0,0\n\tic\t0,#1(1)\n\tmr\tR-,0\n\tstc\tR,#1(1)\n",
 127,0,  63,0,	"F03S00\tl\t1,T\n\tm\tR-,#1(1)\n\tst\tR,#1(1)\n",
 16,5,  16,5,	"F00\tmB2\tFR,A2\n\tstB1\tFR,A1\n",
 16,5,  63,5,	"S02F00\tmd\tFR,T\n\tstB1\tFR,A1\n",
 127,5,  16,5,	"F01\tlB1\tFR,#1(R)\n\tmB2\tFR,A2\n\tstB1\tFR,#1(R)\n",
 127,5,  63,5,	"S02F01\tlB1\tFR,#1(R)\n\tmd\tFR,T\n\tstB1\tFR,#1(R)\n",


# define cr73	&regtabop[82]

 16,3,  63,0,	0,
 16,0,  63,0,	"S00\tlB1\t0,A1\n\tsrda\t0,32\n\tdr\t0,R\n \tstB1\t1,A1\n\tlr\tR+,1\n",
 84,3,  63,0,	0,
 84,0,  63,0,	"S00F05\tlB1\t0,#1(R1)\n\tsrda\t0,32\n\tdr\t0,R\n\tstB1\t1,#1(R1)\n\tlr\tR+,1\n",
 127,0,  63,0,	"S02F01\tlB1\t0,#1(R)\n\tsrda\t0,32\n\td\t0,T\n\tstB1\t1,#1(R)\n\tlr\tR+,1\n",
 16,5,  16,5,	"F00\tdB2\tFR,A2\n\tstB1\tFR,A1\n",
 16,5,  63,5,	"S02F00\tdd\tFR,T\n\tstB1\tFR,A1\n",
 127,5,  16,5,	"F01\tlB1\tFR,#1(R)\n\tmB2\tFR,A2\n\tstB1\tFR,#1(R)\n",
 127,5,  63,5,	"S02F01\tlB1\tFR,#1(R)\n\tdd\tFR,T\n\tstB1\tFR,#1(R)\n",


# define cr74	&regtabop[91]

 16,3,  63,0,	0,
 16,0,  63,0,	"S00\tlB1\t0,A1\n\tsrda\t0,32\n\tdr\t0,R\n\tstB1\t0,A1\n\tlr\tR,0\n",
 84,3,  63,0,	0,
 84,0,  63,0,	"S00F05\tlB1\t0,#1(R1)\n\tsrda\t0,32\n\tdr\t0,R\n\tstB1\t0,#1(R1)\n\tlr\tR,0\n",
 127,0,  63,0,	"S02F01\tlB1\t0,#1(R)\n\tsrda\t0,32\n\td\t0,T\n\tstB1\t0,#1(R)\n\tlr\tR,0\n",


# define cr75	&regtabop[96]

 16,0,  8,0,	"\tlB1\tR,A1\n\tsrl\tR,C2\n\tstB1\tR,A1\n",
 16,0,  63,0,	"S00\tlB1\t1,A1\n\tsrl\t1,0(R)\n\tstB1\t1,A1\n\tlr\tR,1\n",
 127,0,  8,0,	"F01\tlB1\t1,#1(R)\n\tsrl\t1,C2\n\tstB1\t1,#1(R)\n\tlr\tR,1\n",
 84,0,  63,0,	"S00F05\tlB1\t1,#1(R1)\n\tsrl\t1,0(R)\n\tstB1\t1,#1(R1)\n\tlr\tR,1\n",
 127,0,  63,0,	"S02F01\tlB1\t0,#1(R)\n\tl\t1,T\n\tsrl\t0,0(1)\n\tstB1\t0,#1(R)\n\tlr\tR,0\n",


# define cr76	&regtabop[101]

 16,0,  8,0,	"\tlB1\tR,A1\n\tsll\tR,C2\n\tstB1\tR,A1\n",
 16,0,  63,0,	"S00\tlB1\t1,A1\n\tsll\t1,0(R)\n\tstB1\t1,A1\n\tlr\tR,1\n",
 127,0,  8,0,	"F01\tlB1\t1,#1(R)\n\tsll\t1,C2\n\tstB1\t1,#1(R)\n\tlr\tR,1\n",
 84,0,  63,0,	"S00F05\tlB1\t1,#1(R1)\n\tsll\t1,0(R)\n\tstB1\t1,#1(R1)\n\tlr\tR,1\n",
 127,0,  63,0,	"S02F01\tlB1\t0,#1(R)\n\tl\t1,T\n\tsll\t0,0(1)\n\tstB1\t0,#1(R)\n\tlr\tR,0\n",


# define cr70	&regtabop[106]

 16,3,  63,0,	"S20\tsr\t1,1\n\tic\t1,A1\n\tOr\tR,1\n\tstc\tR,A1\n",
 16,0,  63,0,	0,
 16,5,  63,5,	"S20\tOB1\tZ,A1\n\tstB1\tZ,A1\n",
 84,3,  16,1,	0,
 84,0,  16,1,	"F01\tlB1\t0,#1(R)\n\tO\t0,A2\n\tstB1\t0,#1(R)\n\tlr\tR,0\n",
 84,3,  63,0,	"S00F05\tsr\t0,0\n\tic\t0,#1(R1)\n\tOr\tR,0\n\tstc\tR,#1(R1)\n",
 84,0,  63,0,	"S00F05\tO\tR,#1(R1)\n\tst\tR,#1(R1)\n",
 127,0,  16,1,	"F21\tlr\t1,R\n\tlB1\tR,#1(1)\n\tO\tR,A2\n\tstB1\tR,#1(1)\n",
 127,3,  63,0,	"F03S00\tl\t1,T\n\tsr\t0,0\n\tic\t0,#1(1)\n\tOr\tR,0\n\tstc\tR,#1(1)\n",
 127,0,  63,0,	"F03S20\tl\t1,T\n\tO\tR,#1(1)\n\tst\tR,#1(1)\n",
 127,5,  16,5,	"F01\tl\tFR,#1(R)\n\taB2\tFR,A2\n\tstB1\tFR,#1(R)\n",
 127,5,  63,5,	"S02F01\tl\tFR,#1(R)\n\tad\tFR,T\n\tstB1\tFR,#1(R)\n",


# define cr71	&regtabop[118]

 16,3,  63,0,	"S20\tsr\t1,1\n\tic\t1,A1\n\tOr\tR,1\n\tlcr\tR,R\n\tstc\tR,A1\n",
 16,0,  16,1,	"\tl\tR,A1\n\tO\tR,A2\n\tst\tR,A1\n",
 16,0,  63,0,	0,
 16,5,  63,5,	"S20\tOB1\tZ,A1\n\tlcBFr\tZ,Z\n\tstB1\tZ,A1\n",
 84,3,  16,1,	"F01\tsr\t0,0\n\tic\t0,#1(R)\n\tO\t0,A2\n\tstc\t0,#1(R)\n\tlr\tR,0\n",
 84,3,  63,0,	"S00F05\tsr\t0,0\n\tic\t0,#1(R1)\n\tOr\t0,R\n\tstc\t0,#1(R1)\n\tlr\tR,0\n",
 84,0,  16,1,	"F01\tl\t0,#1(R)\n\tO\t0,A2\n\tst\t0,#1(R)\n\tlr\tR,0\n",
 84,0,  63,0,	"S00F05\tO\tR,#1(R1)\n\tlcr\tR,R\n\tst\tR,#1(R1)\n",
 127,3,  16,1,	"F21\tlr\t1,R\n\tsr\tR,R\n\tic\tR,#1(1)\n\tO\tR,A2\n\tstc\tR,#1(1)\n",
 127,3,  63,0,	"F03S00\tl\t1,T\n\tsr\t0,0\n\tic\t0,#1(1)\n\tOr\t0,R\n\tstc\t0,#1(1)\n\tlr\tR,0\n",
 127,0,  16,1,	"F21\tlr\t1,R\n\tl\tR,#1(1)\n\tO\tR,A2\n\tst\tR,#1(1)\n",
 127,0,  63,0,	"F03S20\tl\t1,T\n\tOr\tR,#1(1)\n\tlcr\tR,R\n\tst\tR,#1(1)\n",
 127,5,  16,5,	"F01\tlB1\tFR,#1(R)\n\tsB2\tFR,A2\n\tstB1\tFR,#1(R)\n",
 127,5,  63,5,	"S02F01\tlB1\tFR,#1(R)\n\tsd\tFR,T\n\tstB1\tFR,#1(R)\n",


# define cr51	&regtabop[132]

 16,0,  63,0,	"\tl\tR,A1\n\tmovif\tFR,R\n",
 127,0,  63,0,	"F01\tl\tR,#1(R)\n\tmovif\tFR,R\n",
 63,0,  63,0,	"F20\tmovif\tFR,R\n",


# define cr52	&regtabop[135]

 63,5,  63,0,	"F20\tmovfi\tFR,R\n",

};


struct table regtab[] {

	106,	cr106,	
	32,	cr32,	
	33,	cr32,	
	35,	cr35,	
	36,	cr36,	
	37,	cr37,	
	38,	cr38,	
	101,	cr100,	
	80,	cr80,	
	40,	cr40,	
	41,	cr40,	
	42,	cr42,	
	43,	cr43,	
	44,	cr43,	
	45,	cr45,	
	46,	cr46,	
	47,	cr47,	
	48,	cr40,	
	49,	cr40,	
	70,	cr70,	
	71,	cr71,	
	72,	cr72,	
	73,	cr73,	
	74,	cr74,	
	75,	cr75,	
	76,	cr76,	
	77,	cr70,	
	78,	cr70,	
	79,	cr70,	
	102,	cr102,	
	51,	cr51,
	52,	cr52,
	104,	cr104,	
	107,	cr107,	
	0,	0,
	};

 