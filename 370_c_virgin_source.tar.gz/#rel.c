_rel()
{
return;
}
_access(x)
{
return(x);
}
