# define NFILES 10
struct iobuf {char dd[20], *cp; int out, nchars; char buf[612];};
extern struct iobuf *_fbuffp[NFILES];
